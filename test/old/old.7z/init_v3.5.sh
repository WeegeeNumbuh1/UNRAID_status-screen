#!/bin/bash
# Initialization script for our Python Docker.
# For changelog, check the 'main.py' file. 
# by: WeegeeNumbuh1
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
NC='\033[0m' # No Color
FADE='\033[2m'
CHECK_FILE=/home/first_run_complete

# Define function to send SIGTERM when Docker is shutdown
terminate() {
	echo -e "\n${ORANGE}>>> Shutdown signal received, forwarding to child processes.${NC}"
	kill -15 "$child_pid" 2> /dev/null
	sleep 1s
	}
	
echo -e "\n${ORANGE}>>> Firing up this Docker."
echo -e "${GREEN}>>> Checking dependencies, let's begin.${NC}"
echo -e "${FADE}"
if [ ! -f "$CHECK_FILE" ];
then 
	echo "> First run detected, installing needed dependencies. This may take some time."
	echo "  Notice: Docker memory usage will be higher for this session."
else
	echo "> Last dependencies check:"
	date -r $CHECK_FILE
fi
# hide output
echo "> We're running:"
/usr/local/bin/python -VV
echo "> Packages check:"
echo -ne "░░░░░░░░░░░░░░░░░░░░░░░░░   0% | Checking: pip"
/usr/local/bin/python -m pip install --upgrade pip >/dev/null
echo -ne "\r███░░░░░░░░░░░░░░░░░░░░░░  13% | Checking: pyftdi"
# install dependencies
pip install pyftdi >/dev/null
echo -ne "\r██████░░░░░░░░░░░░░░░░░░░  25% | Checking: adafruit-blinka"
pip install adafruit-blinka >/dev/null
echo -ne "\r█████████░░░░░░░░░░░░░░░░  38% | Checking: circuitpython"
pip install adafruit-circuitpython-rgb-display >/dev/null
echo -ne "\r████████████░░░░░░░░░░░░░  50% | Checking: matplotlib"
pip install matplotlib >/dev/null
echo -ne "\r███████████████░░░░░░░░░░  63% | Checking: matplotx"
pip install matplotx >/dev/null
echo -ne "\r██████████████████░░░░░░░  75% | Checking: Pillow"
pip install Pillow >/dev/null
echo -ne "\r█████████████████████░░░░  88% | Checking: psutil"
pip install psutil >/dev/null
echo -e "\r░░░▒▒▓▓ Completed ▓▓▒▒░░░ 100%                              "
echo "> List of installed Python packages:"
pip list
echo "> Checking system image..."
apt-get update >/dev/null
apt-get install -y libusb-1.0-0 >/dev/null
echo "> System image ready."
touch $CHECK_FILE
echo -e "${NC}"
echo -e "${GREEN}>>> Dependencies check complete."
echo -e "${ORANGE}>>> Entering main loop!${NC}"
echo -e "${FADE}"
echo "                                                  ";
echo "   ██   ██ ███   ██ ██████   █████  ██ ██████     ";
echo "   ██   ██ ████  ██ ██   ██ ██   ██ ██ ██   ██    ";
echo "   ██   ██ ██ ██ ██ ██████  ███████ ██ ██   ██    ";
echo "   ██   ██ ██  ████ ██   ██ ██   ██ ██ ██   ██    ";
echo "    █████  ██   ███ ██   ██ ██   ██ ██ ██████     ";
echo "                                                  ";
echo "███████ ████████  █████  ████████ ██   ██ ███████ ";
echo "██         ██    ██   ██    ██    ██   ██ ██      ";
echo "███████    ██    ███████    ██    ██   ██ ███████ ";
echo "     ██    ██    ██   ██    ██    ██   ██      ██ ";
echo "███████    ██    ██   ██    ██     █████  ███████ ";
echo "                                                  ";
echo " ███████  █████ ██████  ███████ ███████ ███   ██  ";
echo " ██      ██     ██   ██ ██      ██      ████  ██  ";
echo " ███████ ██     ██████  █████   █████   ██ ██ ██  ";
echo "      ██ ██     ██   ██ ██      ██      ██  ████  ";
echo " ███████  █████ ██   ██ ███████ ███████ ██   ███  ";
echo "                                                  ";
echo "   ░       ░      ░             ░  ░     ░    ░   ";
echo " ░ ░  ░   ░░   ░  ▒  ░░      ░  ▒  ░ ░   ░    ░   ";
echo " ░ ▒  ▒   ░▒ ░ ▒░ ▒  ░▒ ░    ▒  ▒▒░░ ░   ░  ░ ▒  ░";
echo " ▒▒▓▒ ▒ ░ ▒▓ ░▒▓░░▓  ▒▓▒░ ░░▒▒  ▓▒▓░ ░▒  ▒ ░░ ▒░ ░";
echo "░▒▓▓▓▓▓ ░▓▓▓ ▒▓▓▒░▓▓░▒▓███  by: WeegeeNumbuh1  ███";

# fire up the script and watch over it
trap terminate SIGTERM
/usr/local/bin/python /app/main.py & child_pid=$!
wait "$child_pid"