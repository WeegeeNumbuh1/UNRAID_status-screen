import os
import time
import signal
import sys
from collections import deque
# Blinka CircuitPython
import board
import digitalio
import adafruit_rgb_display.ili9341 as ili9341
from pyftdi.ftdi import Ftdi
# Python Imaging Library
from PIL import Image
# Matplotlib
import matplotlib.pyplot as plt
# System Stats
import psutil

# check variables
print('Is the environment varible set?\n',os.environ["BLINKA_FT232H"])
print('Check if the display is connected:')
try:
    Ftdi().open_from_url('ftdi:///?')
except:
    pass
    
# Setup display
cs_pin = digitalio.DigitalInOut(board.C0)
dc_pin = digitalio.DigitalInOut(board.C1)
rst_pin = digitalio.DigitalInOut(board.C2)
disp = ili9341.ILI9341(board.SPI(), cs=cs_pin, dc=dc_pin, rst=rst_pin, baudrate=24000000)

# Have a splash screen while loading
bg_image = Image.open('/app/background.bmp').convert('RGB')
disp.image(bg_image, 180)

# check when the Docker is shutdown
def sigterm_handler(signal, frame):
    # Raises SystemExit(0):
    disp.image(bg_image, 180)
    print("Main loop stopped. See you next time!")
    sys.exit(0)

#pylint: disable=bad-continuation
#==| User Config |========================================================
REFRESH_RATE = 1
HIST_SIZE = 61
PLOT_CONFIG = (
    #--------------------
    # PLOT 1 (upper plot)
    #--------------------
    {
    'title' : 'CPU load',
    'ylim' : (0, 100),
    'line_config' : (
        {'color' : '#0000FF', 'width' : 2},
        {'color' : '#0060FF', 'width' : 2},
        {'color' : '#00FF60', 'width' : 2},
        {'color' : '#60FF00', 'width' : 2},
        )
    },
    #--------------------
    # PLOT 2 (lower plot)
    #--------------------
    {
    'title' : 'Disk Activity (MB/s)',
    'ylim' : (0, 1000),
    'line_config' : (
        {'color' : '#62CE25', 'width' : 2}, # sent
        {'color' : '#145CDA', 'width' : 2}, # recv
        )
    }
)

CPU_COUNT = psutil.cpu_count(logical=True)

def update_data():
    ''' Do whatever to update your data here. General form is:
           y_data[plot][line].append(new_data_point)
    '''
    cpu_percs = psutil.cpu_percent(interval=REFRESH_RATE, percpu=False)
    # for cpu in range(CPU_COUNT):
    y_data[0][0].append(cpu_percs)
    
    # # Network speed
    # # get two data points
    # net_start = psutil.net_io_counters()
    # time.sleep(REFRESH_RATE)
    # net_finish = psutil.net_io_counters()

    # # rate is d()/dt
    # BPS_sent = (net_finish.bytes_sent - net_start.bytes_sent) / REFRESH_RATE
    # BPS_recv = (net_finish.bytes_recv - net_start.bytes_recv) / REFRESH_RATE
    # y_data[1][0].append(BPS_sent / 1e6)
    # y_data[1][1].append(BPS_recv / 1e6)
    
    # disk I/O
    disk_start = psutil.disk_io_counters()
    time.sleep(REFRESH_RATE)
    disk_finish = psutil.disk_io_counters()
    
    # rate is d()/dt
    iospeed_read = (disk_finish.read_bytes - disk_start.read_bytes) / REFRESH_RATE
    iospeed_write = (disk_finish.write_bytes - disk_start.write_bytes) / REFRESH_RATE
    y_data[1][0].append(iospeed_read / 1e6)
    y_data[1][1].append(iospeed_write / 1e6)

#==| User Config |========================================================
#pylint: enable=bad-continuation

# Setup X data storage
x_time = [x * REFRESH_RATE for x in range(HIST_SIZE)]
x_time.reverse()

# Setup Y data storage
y_data = [ [deque([None] * HIST_SIZE, maxlen=HIST_SIZE) for _ in plot['line_config']]
           for plot in PLOT_CONFIG
         ]

# Setup plot figure
plt.style.use('dark_background')
fig, ax = plt.subplots(2, 1, figsize=(disp.width / 100, disp.height / 100))

# Setup plot axis
ax[0].xaxis.set_ticklabels([])
for plot, a in enumerate(ax):
    # add grid to all plots
    a.grid(True, linestyle=':')
    # limit and invert x time axis
    a.set_xlim(min(x_time), max(x_time))
    a.invert_xaxis()
    # custom settings
    if 'title' in PLOT_CONFIG[plot]:
        a.set_title(PLOT_CONFIG[plot]['title'], position=(0.5, 0.8))
    if 'ylim' in PLOT_CONFIG[plot]:
        a.set_ylim(PLOT_CONFIG[plot]['ylim'])

# Setup plot lines
#pylint: disable=redefined-outer-name
plot_lines = []
for plot, config in enumerate(PLOT_CONFIG):
    lines = []
    for index, line_config in enumerate(config['line_config']):
        # create line
        line, = ax[plot].plot(x_time, y_data[plot][index])
        # custom settings
        if 'color' in line_config:
            line.set_color(line_config['color'])
        if 'width' in line_config:
            line.set_linewidth(line_config['width'])
        if 'style' in line_config:
            line.set_linestyle(line_config['style'])
        # add line to list
        lines.append(line)
    plot_lines.append(lines)

def update_plot():
    # update lines with latest data
    for plot, lines in enumerate(plot_lines):
        for index, line in enumerate(lines):
            line.set_ydata(y_data[plot][index])
        # autoscale if not specified
        if 'ylim' not in PLOT_CONFIG[plot].keys():
            ax[plot].relim()
            ax[plot].autoscale_view()
    # draw the plots
    canvas = plt.get_current_fig_manager().canvas
    plt.tight_layout()
    canvas.draw()
    # transfer into PIL image and display
    image = Image.frombytes('RGB', canvas.get_width_height(), canvas.tostring_rgb())
    disp.image(image, 180)

def main():
    print("Monitoring started.")
    # register handler for SIGTERM
    signal.signal(signal.SIGTERM, sigterm_handler)
    while True:
        update_data()
        update_plot() # update rate controlled by psutil.cpu_percent()

# finally enter main loop
if __name__ == '__main__':
    main()

# # Load image and convert to RGB
# image = Image.open('/app/blinka.bmp').convert('RGB')
# print('Image generated.')

# # Display it (rotated by 90 deg)
# disp.image(image, 90)
