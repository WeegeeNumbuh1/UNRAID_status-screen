'''
UNRAID system monitoring screen script
Powered by Python, matplotlib, and psutil
Designed to run completely in Docker

by: WeegeeNumbuh1

Based on scripts from:
https://github.com/adafruit/Adafruit_Learning_System_Guides/tree/main/TFT_Sidekick_With_FT232H
'''
import time
start_time = round(time.time(), 3) # start timing this script
import datetime
STARTED_DATE = datetime.datetime.now()
VERSION = "v.3.3 --- 2024-03-11"
print(f"Script version: {VERSION}")
print(f"Script started: {STARTED_DATE}")

#==| User Config |========================================================

DEBUG = True
'''
If True, render the amount of time it took to render the last frame in the plot itself.
Also outputs more info in the log. Personally, I leave this set to True.
'''
REFRESH_RATE = 2 # in seconds
'''
Don't set REFRESH_RATE too low - we don't want to waste too much CPU.
We need to allow update_plot() to finish while update_data() is still running
to get a more accurate represenation of CPU usage. The rendering portion
is the most CPU intensive action in this script and we should let it finish
while the workers in update_plot() are sleeping.
Testing has shown it takes roughly 100 - 300 milliseconds to render
the entire plot and send it to the display; if REFRESH_RATE is too low then
we are limited to how fast update_plot() can complete.
    REFRESH_RATE should be >= 0.5
'''
HIST_SIZE = 61 
''' how long to keep data; total time = REFRESH_RATE * (HIST_SIZE - 1) '''
ARRAY_PATH = "/rootfs/mnt/user0"
''' /rootfs/mnt/user0 is our Unraid array inside this Docker '''
CPU_TEMP_SENSOR = "k10temp"
'''
Check the output of psutil.sensors_temperatures() on
your system then update with the correct sensor.
''' 
PLOT_CONFIG = (
    #--------------------
    # PLOT 1 (upper plot)
    #--------------------
    {
    #'title' : 'CPU',
    'ylim' : (0, 100),
    'line_config' : (
        {'width': 1, 'alpha': 0.6}, # CPU
        {'width': 1, 'alpha': 0.6}  # Temps
        )
    },
    #--------------------
    # PLOT 2 (CPU core heatmap)
    #--------------------
    {
    #'title' : 'CPU heatmap',
    #'ylim' : (0, 100),
    'line_config' : (
        {}, # need this just so we can plot
        )
    },
    #--------------------
    # PLOT 3 (middle plot)
    #--------------------
    {
    #'title' : 'Disks (MB/s)',
    # 'ylim' : (0, 1000),
    'line_config' : (
        {'width': 1, 'alpha': 0.6}, # read
        {'width': 1, 'alpha': 0.6}, # write
        )
    },
    #--------------------
    # PLOT 4 (bottom plot)
    #--------------------
    {
    #'title' : 'Network (MB/s)',
    #'ylim' : (0, 1000),
    'line_config' : (
        {'width': 1, 'alpha': 0.6}, # sent
        {'width': 1, 'alpha': 0.6}, # received
        )
    },
    #--------------------
    # PLOT 5 (Resource usage)
    #--------------------
    {
    #'title' : 'Resources',
    'line_config' : (
        {} # a bar graph
    )
    }
)
''' 
Valid plot properties are:
    - title = name your subplot (not recommended for this setup, UNTESTED)
    - ylim (min, max) = y-axis limits
        (NB: if ylim is not set, matplotlib will automatically scale for us)
- for lines:
    color, width, style, alpha
'''
ax_name = ("CPU", 
           "Core Heatmap", 
           "Disk", 
           "Network",
           "")
''' ---REQUIRED--- Names in the center of the subplots, one per plot. '''

#==| End User Config |========================================================

''' Continue our setup '''
import os, signal, sys
os.nice(19) # make sure this entire script runs at lowest priority
import threading
from collections import deque
import concurrent.futures as CF
# Blinka CircuitPython
import board
import digitalio
import adafruit_rgb_display.ili9341 as ili9341
from pyftdi.ftdi import Ftdi
# Python Imaging Library
from PIL import Image
# Matplotlib
import matplotlib.pyplot as plt
import matplotlib
import matplotx
import numpy as np
# System Stats
import psutil
from psutil._common import bytes2human

'''
Changelog:
- v.3.3 (2024-03-11)
    - added profiling option to adjust plot rendering timeout based on hardware performance
    - lowered process priority to minimum (remember this is just a system resource monitor)
    - moved user-config section to the beginning of script
- v.3.2 (2024-03-10)
    - FIXED: Memory leak due to heatmap and bar graph introduced in v.1.x
    - some more code refactoring
- v.3.1 (2024-03-09)
    - optimizations for string manipulation, improving per-loop times (extra ~10%)
    - more accurate timing info and new sample stat when SIGTERM'd
    - revised debug output on rendered image
    - verbose changelog
- v.3.0 (2024-03-09)
    - switch to using ThreadPoolExecutor for better performance (almost 2x speed up)
    - improved docstrings and code readability
    - better exception handling, settings validation, and timeout checks
    - refactoring to make it easier to switch between debugging in VSCode in Windows and actual hardware (this was for me)
- v.2.1 (2024-03-07)
    - add debug flags and print stats to screen and log
- v.2.0 (2024-03-06)
    - finalize layout
    - figure out multithreading and refactor around this
- v.1.x (2024-03-02)
    - learn how to actually code in Python
    - figure out how to use matplotlib correctly
    - determine what resources to monitor
    - initial layout changes for plot
    - how do I VSCode
- v.0.x (2024-02)
    - get this script to actually run in a Docker environment
    - modify the script this is based on for my use
    - graceful exit for when Docker exits (SIGTERM handler here and in init.sh)
    - splash screen
'''

# Check variables
print("- Is the environment varible set?\n",os.environ["BLINKA_FT232H"])
print("- Check if the display is connected:")
try: # this will throw an error regardless
    Ftdi().open_from_url('ftdi:///?')
except:
    pass
    
# Setup display
cs_pin = digitalio.DigitalInOut(board.C0)
dc_pin = digitalio.DigitalInOut(board.C1)
rst_pin = digitalio.DigitalInOut(board.C2)
disp = ili9341.ILI9341(board.SPI(), cs=cs_pin, dc=dc_pin, rst=rst_pin, baudrate=24000000)
print(f"Display size: {disp.width}x{disp.height}")

# Have a splash screen while loading
bg_image = Image.open('/app/background.bmp').convert('RGB')
disp.image(bg_image, 180)

# Check when the Docker is shutdown
def sigterm_handler(signal, frame):
    # raises SystemExit(0):
    mainpool.shutdown(wait=False, cancel_futures=True)
    disp.image(bg_image, 180) # leave a splash screen up when we exit
    end_time = round(time.time() - start_time, 3)
    print(f"- Script ran for {datetime.timedelta(seconds=end_time)} and sampled {samples} times.")
    print("Main loop stopped. See you next time!")
    sys.exit(0)

# Start our thread pool before anything
mainpool = CF.ThreadPoolExecutor(max_workers=6)
'''
We expect to only run the following:
- update_data() ← one thread
    - 4 workers
- update_plot() ← another thread
- Σ = 6
'''

debugVSCodeWin = False
'''
I debugged this in Windows VSCode lmao.
Don't forget to set this to False when running on actual hardware!
'''

# no traceback fluff
sys.tracebacklimit = 0

if debugVSCodeWin == True:
    timeoutwait = REFRESH_RATE * 40 # raise it for testing
    ARRAY_PATH = 'C:\\'
    class disp: # substitute display properties
        width = 240
        height = 320
    def sigterm_handler(): 
        pass
else:
    timeoutwait = REFRESH_RATE + 0.25
    matplotlib.use('Agg', force=True) 

if DEBUG == True:
    print(f"Using matplotlib {matplotlib.__version__}, {matplotlib.get_backend()} backend")

# Initialize a sample counter
samples = 0

PROFILING = True
''' Enable or disable the thread timeout profiler, recommended to be left as True '''
if PROFILING == True:
    profilercount = 240 # how many samples for our profiler
timearray = []

# Setup array of strings we can put latest sensor info into
current_data = []
for plot in PLOT_CONFIG: # this will make n+1 indices, perfect for our debug
    for _ in plot['line_config']:
        current_data.append(None)
current_data[-1] = "" # utilize that last index
cpu_percs_cores = [] # setup array for CPU core utilization

# Setup X data storage
x_time = [x * REFRESH_RATE for x in range(HIST_SIZE)]
x_time.reverse()

# Setup Y data storage
y_data = [ [deque([None] * HIST_SIZE, maxlen=HIST_SIZE) for _ in plot['line_config']]
           for plot in PLOT_CONFIG
         ]

# Setup plot figure
plt.style.use(matplotx.styles.ayu['dark']) # Ayumu Uehara?
fig, ax = plt.subplots(5, 1, figsize=(disp.width / 100, disp.height / 100),
                       gridspec_kw={'height_ratios': [4, 1, 4, 4, 2]})
fig.subplots_adjust(0.0,0.12,1,0.98) # adjust extent of margins (left, bottom, right, top)
plt.rcParams.update({'font.size': 6})
plt.ioff # hopefully speeds things up a bit

# Set up text objects we can update
if DEBUG == True:
    debug_text = ax[4].annotate('', [1, -0.5], xycoords='axes fraction', 
                          verticalalignment='top', horizontalalignment='right')
    plot_settings = ax[4].annotate(f"Refresh: {REFRESH_RATE}s | Plot range: {REFRESH_RATE * (HIST_SIZE - 1)}s",
                               [0, -0.5], xycoords='axes fraction',
                               verticalalignment='top', horizontalalignment='left')
cpu_text = ax[0].annotate('', [0.5, 0.3], xycoords='axes fraction', 
                          verticalalignment='center',
                          horizontalalignment='center',
                          fontweight='black')
uptimetext = ax[2].annotate('', [0.5, 1.1], xycoords='axes fraction', 
                             verticalalignment='top',
                             horizontalalignment='center',
                             alpha=1)
disk_text = ax[2].annotate('', [0.5, 0.3], xycoords='axes fraction', 
                          verticalalignment='center',
                          horizontalalignment='center',
                          fontweight='black')
network_text = ax[3].annotate('', [0.5, 0.3], xycoords='axes fraction', 
                          verticalalignment='center',
                          horizontalalignment='center',
                          fontweight='black')
memory_text = ax[4].annotate('', [0.5, 0.75], xycoords='axes fraction', 
                          verticalalignment='center',
                          horizontalalignment='center',
                          fontweight='black')
storage_text = ax[4].annotate('', [0.5, 0.25], xycoords='axes fraction', 
                          verticalalignment='center',
                          horizontalalignment='center',
                          fontweight='black')

def annotate_axes(ax, text, fontsize=10):
    ''' Puts text in the center of the plots '''
    ax.text(0.5, 0.5, text, transform=ax.transAxes,
            ha='center', va='center', fontsize=fontsize, 
            fontstyle='italic', fontweight='normal', 
            fontstretch= 600, alpha=0.25)
    
# Setup plot axis
for plot, a in enumerate(ax):
    # custom settings
    if 'title' in PLOT_CONFIG[plot]:
        a.set_title(PLOT_CONFIG[plot]['title'], position=(0.5, 0.8))
    if 'ylim' in PLOT_CONFIG[plot]:
        a.set_ylim(PLOT_CONFIG[plot]['ylim'])
    if plot == 1: # this is our CPU core heatmap
        a.axis('off')
        # a.yaxis.set_ticklabels([]) # turn off y-tick labels
        # a.set_yticks([])
        continue
    a.xaxis.set_ticklabels([])
    a.tick_params(axis='y', direction='in', pad=-20, labelsize=5)
    a.tick_params(axis='y', which='minor', left=False)
    a.tick_params(axis='x', which='minor', bottom=False)
    if plot == 4: # this is our CPU core heatmap & barplot
        a.tick_params(bottom = False, left=False)
    # turn off all spines
    a.spines['top'].set_visible(False)  
    a.spines['bottom'].set_visible(False)  
    a.spines['right'].set_visible(False)  
    a.spines['left'].set_visible(False)
    # limit and invert x time axis
    if plot == 4: # we don't need to set the x-limits here
        continue
    a.set_xlim(min(x_time), max(x_time))
    a.invert_xaxis()

# Setup plot lines
plot_lines = []
for plot, config in enumerate(PLOT_CONFIG):
    lines = []
    for index, line_config in enumerate(config['line_config']):
        # create line
        line, = ax[plot].plot(x_time, y_data[plot][index])
        # custom settings
        if 'color' in line_config:
            line.set_color(line_config['color'])
        if 'width' in line_config:
            line.set_linewidth(line_config['width'])
        if 'style' in line_config:
            line.set_linestyle(line_config['style'])
        if 'alpha' in line_config:
            line.set_alpha(line_config['alpha'])
        # add line to list
        lines.append(line)
    plot_lines.append(lines)
    annotate_axes(ax[plot],ax_name[plot])

# Make plot 1 a heatmap
corecount = psutil.cpu_count()
heatmap = ax[1].imshow(np.matrix(np.zeros(corecount)),
                       cmap='hot', vmin=0, vmax=100, aspect='auto')

# Make plot 4 a horizontal bar graph
barplot = ax[4].barh([1, 2], [0, 0], color=['#375e1f','#4a2a7a']) ; ax[4].set_xlim(right=100) 
ax[4].set_yticks([1, 2],["Array", "Memory"])

# Grab an image of the background, maybe for when we decide to use animations for this
# initial_render = [fig.canvas.copy_from_bbox(ax.bbox) for ax in ax]

def update_data():
    '''
    Generates data for our plot.
    Sends workers to run in our thread pool, waits for them to finish,
    then finishes. The workers sleep for REFRESH_RATE then append to y_data
    and current_data[].
    General form is:
           y_data[plot][line].append(new_data_point)
    Fun fact: this whole routine takes approximately 30 - 70 milliseconds to
    finish, ignorning the blocking done during the REFRESH_RATE interval.
    '''

    # data_start = round(time.time(), 3) # to check how long this function takes
    def cpu_data_load():
        cpu_percs = psutil.cpu_percent(interval=REFRESH_RATE, percpu=False)
        y_data[0][0].append(cpu_percs)
        cpu_freq = psutil.cpu_freq() ; cpu_f_ghz = round(cpu_freq.current / 1000, 2)
        current_data[0] = f"{cpu_percs}% @ {cpu_f_ghz} GHz"
        if debugVSCodeWin == True: # sensors_temperatures() does not exist in Windows
            y_data[0][1].append(None)
            current_data[1] = None
        else:
            cpu_temp = psutil.sensors_temperatures()[CPU_TEMP_SENSOR][0].current
            y_data[0][1].append(cpu_temp)
            current_data[1] = f"{round(cpu_temp, 1)}°C"
        
    def cpu_data_core():
        global cpu_percs_cores
        cpu_percs_cores = psutil.cpu_percent(interval=REFRESH_RATE, percpu=True)
        # then do this just in case the loop in update_plot() does something freaky
        y_data[1][0].append(1)

    def disk_data():
        # disk I/O, in MB/s
        disk_start = psutil.disk_io_counters()
        time.sleep(REFRESH_RATE)
        disk_finish = psutil.disk_io_counters()
        iospeed_read = (disk_finish.read_bytes - disk_start.read_bytes) / REFRESH_RATE
        iospeed_write = (disk_finish.write_bytes - disk_start.write_bytes) / REFRESH_RATE
        y_data[2][0].append(iospeed_read / 1e6)
        y_data[2][1].append(iospeed_write / 1e6)
        current_data[2] = f"R:{round(iospeed_read / 1e6, 2)} MB/s"
        current_data[3] = f"W:{round(iospeed_write / 1e6, 2)} MB/s"

    def network_data():
        # network speed, in MB/s
        net_start = psutil.net_io_counters()
        time.sleep(REFRESH_RATE)
        net_finish = psutil.net_io_counters()
        network_sent = (net_finish.bytes_sent - net_start.bytes_sent) / REFRESH_RATE
        network_recv = (net_finish.bytes_recv - net_start.bytes_recv) / REFRESH_RATE
        y_data[3][0].append(network_sent / 1e6)
        y_data[3][1].append(network_recv / 1e6)
        current_data[4] = f"↑ {round(network_sent / 1e6, 1)} MB/s"
        current_data[5] = f"↓ {round(network_recv / 1e6, 1)} MB/s"
    
    '''
    This was the old way of threading; this was much slower
    Kept here for notoriety.
    '''
    # t1 = threading.Thread(target=cpu_data_load, name='CPU Poller', daemon=True)
    # t2 = threading.Thread(target=cpu_data_core, name='CPU Core Poller', daemon=True)
    # t3 = threading.Thread(target=disk_data, name='Disk Poller', daemon=True)
    # t4 = threading.Thread(target=network_data, name='Network Poller', daemon=True)
    # t1.start() ; t2.start() ; t3.start() ; t4.start()
    # t1.join() ; t2.join() ; t3.join() ; t4.join()

    '''
    Gather stats over REFRESH_RATE instead of waiting for each one sequentially
    and use the thread pool
    '''
    cpupoll = mainpool.submit(cpu_data_load)
    cpucorepoll = mainpool.submit(cpu_data_core)
    diskpoll = mainpool.submit(disk_data)
    networkpoll = mainpool.submit(network_data)
    try: # block until all threads finish
        _ = cpupoll.result(timeout=timeoutwait)
        _ = cpucorepoll.result(timeout=timeoutwait)
        _ = diskpoll.result(timeout=timeoutwait)
        _ = networkpoll.result(timeout=timeoutwait)
    except TimeoutError:
        if DEBUG == True:
            print("Worker threads are taking too long!")
        itbroke(1)
    except:
        itbroke(2)
    #print(f"--- data: {round((time.time() - (data_start + REFRESH_RATE)), 3)} seconds ---")

def update_plot():
    '''
    Read the last polled data generated by update_data(). This will run as soon as update_data() is run
    so that while the workers in update_data() are sleeping we can focus on generating the plot. 
    This has the effect of the workers being able to monitor the load this thread imposes.
    '''
    mutex = threading.Lock()
    global current_data
    plot_start = round(time.time(), 3)
    # gather system stats
    UPTIME = f"Uptime: {datetime.timedelta(seconds=round(time.monotonic()))}"
    array_use = psutil.disk_usage(ARRAY_PATH)
    array_total = bytes2human(array_use.total) ; array_used = bytes2human(array_use.used)
    array_str = f"{array_used} / {array_total} ({array_use.percent}%)"
    memory_use = psutil.virtual_memory()
    memory_total = bytes2human(memory_use.total) ; memory_used = bytes2human(memory_use.used)
    memory_str = f"{memory_used} / {memory_total} ({memory_use.percent}%)"
    # update lines with latest data
    with mutex: # lock variables just in case
        for plot, lines in enumerate(plot_lines):
            if plot == 1 or plot == 4: # don't plot over our non-graph subplots
                continue
            for index, line in enumerate(lines):
                line.set_ydata(y_data[plot][index])
            # autoscale if not specified
            if 'ylim' not in PLOT_CONFIG[plot].keys():
                ax[plot].relim()
                ax[plot].autoscale_view()

        # update our heatmap
        heatmap.set_data(np.matrix(cpu_percs_cores))
        # update our barplot
        barplot[0].set_width(array_use.percent)
        barplot[1].set_width(memory_use.percent)
        ''' original setup; this WILL cause a memory leak '''
        # ax[1].pcolormesh([cpu_percs_cores], cmap='hot', vmin=0, vmax=100)
        # ax[4].barh(1, array_use.percent, facecolor='#375e1f')
        # ax[4].barh(2, memory_use.percent, facecolor='#4a2a7a')
        
        # update text in plots with last polled data
        if current_data[1] == None:
            cpu_text.set_text(current_data[0])
        else:
            cpu_text.set_text(f"{current_data[0]} | {current_data[1]}")
        disk_text.set_text(f"{current_data[2]} | {current_data[3]}")
        storage_text.set_text(array_str)
        memory_text.set_text(memory_str)
        network_text.set_text(f"{current_data[4]} | {current_data[5]}")
        uptimetext.set_text(UPTIME)
        
    if DEBUG == True:
       debug_text.set_text(f"Last render: {current_data[-1]}s")
    # draw the plots
    canvas = plt.get_current_fig_manager().canvas
    canvas.draw()
    if debugVSCodeWin == False: # how it should be
        '''
        Transfer into PIL image and display. tostring_rgb() is depreciated in matplotlib >= 3.8
        with no direct replacement. This will throw a warning on first run, oh well.
        '''
        image = Image.frombytes('RGB', canvas.get_width_height(), canvas.tostring_rgb())
        disp.image(image, 180)
    else:
        pass
    # fig.canvas.flush_events()
    current_data[-1] = f"{round(time.time() - plot_start, 3)}"
#    print("--- generate: %s seconds ---" % current_data[-1])

def check_settings():
    '''
    Checks if the settings are correct and stops this script from continuing
    if they're incorrect or invalid.
    '''
    if debugVSCodeWin == True:
        print("Settings are valid.")
    else:
        try:
            test1 = psutil.sensors_temperatures()[CPU_TEMP_SENSOR][0].current
            test2 = psutil.disk_usage(ARRAY_PATH)
            del test1;test2
            print("Settings are valid.")
        except:
            raise ValueError("Settings are incorrect! Check your settings and try again.")
            
def itbroke(type):
    disp.image(bg_image, 180)
    mainpool.shutdown(wait=False, cancel_futures=True)
    end_time = round(time.time() - start_time, 3)
    print(f"- Script ran for {datetime.timedelta(seconds=end_time)} and sampled {samples} times.")
    if type == 1:
        raise ResourceWarning("Script terminated due to potential resource exhaustion.")
    else:
        raise GeneratorExit("Script terminated.")
        
def plotprofiler(samples, samplesize):
    '''
    We profile how long it takes to actually render the image on your specific hardware
    then adjust the thread timeout so we can set better limits.
    '''
    global timearray
    if samples == 0:
        timearray = []
    elif samples > 0 and samples < samplesize:
        timearray.append(eval(current_data[-1]))
    elif samples == samplesize:
        timearray.append(eval(current_data[-1]))
        avgrender = round(sum(timearray) / samplesize, 4)
        realtimeout = (avgrender * 5) # if it takes longer, kill this script
        print(f"Profiler done with {samplesize} samples. Average render time: {avgrender}s.")
        del timearray
        return realtimeout
    elif samples > samplesize: # in case we use this past the polling amount
        realtimeout = timeoutwait
        return realtimeout
    else:
        print("Profiler failed to determine execution time. Non-critial error.")

def main():
    '''Loop until Docker shuts down or something breaks.'''
    print(f"Setup took {round(time.time() - start_time, 3)} seconds")
    check_settings()
    print(f"--- Monitoring started, refresh rate: {REFRESH_RATE} second(s) ---")
    # register handler for SIGTERM
    if debugVSCodeWin == False:
        signal.signal(signal.SIGTERM, sigterm_handler)
    if DEBUG == True:
        print("Performance tracing enabled, render times will be displayed.")
    update_data() # get initial stats on startup
    global samples
    actualtimeout = timeoutwait
    if REFRESH_RATE < 1:
        actualtimeout = 1
    while True:
        ''' old way of doing threads '''
        # t1 = threading.Thread(target=update_data, daemon=True) ; t1.name = 'Data Poller'
        # t2 = threading.Thread(target=update_plot,daemon=True); t2.name = 'Plotter'
        # t1.start() ; t2.start()
        # t2.join() ; t1.join()
        datapoller = mainpool.submit(update_data)
        plotter = mainpool.submit(update_plot)
        try: # block until threads finish
            _ = datapoller.result(timeout=timeoutwait)
            _ = plotter.result(timeout=actualtimeout)
        except TimeoutError:
            if DEBUG == True:
                print("Main threads taking too long!")
            itbroke(1)
        except:
            itbroke(2)
        
        if PROFILING == True:
            if samples == 0:
                plotprofiler(samples, profilercount)
            elif samples < profilercount:
                plotprofiler(samples, profilercount)
            elif samples == profilercount:
                actualtimeout = plotprofiler(samples, profilercount)
            else:
                pass
                
        samples +=1

# finally enter main loop
if __name__ == '__main__':
    main()
