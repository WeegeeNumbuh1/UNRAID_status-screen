#!/bin/bash
# Initialization script for our Python Docker.
# For changelog, check the 'main.py' file. 
# by: WeegeeNumbuh1
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
NC='\033[0m' # No Color
FADE='\033[2m'
CHECK_FILE=/home/first_run_complete
PROFILING_FLAG=/app/profile

# Define function to send SIGTERM when Docker is shutdown
terminate() {
	echo -e "\n${ORANGE}>>> Shutdown signal received, forwarding to child processes.${NC}"
	kill -15 "$child_pid" 2> /dev/null
	sleep 1s
	}
	
echo -e "\n${ORANGE}>>> Firing up this Docker."
echo -e "${GREEN}>>> Checking dependencies, let's begin.${NC}"
echo -e "${FADE}"
if [ ! -f "$CHECK_FILE" ];
then 
	echo "> First run detected, installing needed dependencies.
  This may take some time depending on your internet connection."
	echo "  Notice: Docker memory usage will be higher for this session."
	VERB_TEXT='Installing: '
else
	echo -n "> Last dependencies check: "
	date -r $CHECK_FILE
	VERB_TEXT='Checking: '
fi
echo "> Checking system image..."
apt-get update >/dev/null
dpkg --configure -a >/dev/null
apt-get install -y libusb-1.0-0 >/dev/null
# apt-get install -y pypy3 >/dev/null
echo "> System image ready."
echo -n "> We have: "
/usr/local/bin/python -VV
# Unraid's Docker log does not show lines until it encounters a newline so we do the below:
CHECKMARK='\e[1F\e[30C✅\n' # move cursor up to the beginning one line up then move 30 spaces right
# If you use Dozzle, the above will show up as "FC✅", RIP
# install dependencies
echo "> Packages check:"
#printf '%spip' "${VERB_TEXT}"
echo -e "${VERB_TEXT}pip"
/usr/local/bin/python -m pip install --upgrade pip >/dev/null
#printf ' ✅\n%spyftdi' "${VERB_TEXT}"
echo -e "${CHECKMARK}${VERB_TEXT}pyftdi"
pip install --upgrade pyftdi >/dev/null
#printf ' ✅\n%sadafruit-blinka' "${VERB_TEXT}"
echo -e "${CHECKMARK}${VERB_TEXT}adafruit-blinka"
pip install --upgrade adafruit-blinka >/dev/null
#printf ' ✅\n%scircuitpython' "${VERB_TEXT}"
echo -e "${CHECKMARK}${VERB_TEXT}circuitpython"
pip install --upgrade adafruit-circuitpython-rgb-display >/dev/null
#printf ' ✅\n%smatplotlib' "${VERB_TEXT}"
echo -e "${CHECKMARK}${VERB_TEXT}matplotlib"
pip install --upgrade matplotlib >/dev/null
pip install --upgrade matplotx >/dev/null
#printf ' ✅\n%sPillow' "${VERB_TEXT}"
echo -e "${CHECKMARK}${VERB_TEXT}Pillow"
pip install --upgrade Pillow >/dev/null
#printf ' ✅\n%spsutil' "${VERB_TEXT}"
echo -e "${CHECKMARK}${VERB_TEXT}psutil"
pip install --upgrade psutil >/dev/null
if [ -f "$PROFILING_FLAG" ];
then
	#printf ' ✅\nℹ️ Profiling flag detected -> %sscalene' "${VERB_TEXT}"
	echo -e "${CHECKMARK}ℹ️ Profiling flag detected\n -> ${VERB_TEXT}scalene"
	pip install --upgrade scalene >/dev/null
fi
#printf " ✅\n░░░▒▒▓▓ Completed ▓▓▒▒░░░\n"
echo -e "${CHECKMARK}░░░▒▒▓▓ Completed ▓▓▒▒░░░\n"
#echo "> List of installed Python packages:"
#pip list # for debug
touch $CHECK_FILE
echo -e "${NC}"
echo -e "${GREEN}>>> Dependencies check complete."
echo -e "${ORANGE}>>> Entering main loop!${NC}"
echo -e "${FADE}"
echo "                                                  ";
echo "   ██   ██ ███   ██ ██████   █████  ██ ██████     ";
echo "   ██   ██ ████  ██ ██   ██ ██   ██ ██ ██   ██    ";
echo "   ██   ██ ██ ██ ██ ██████  ███████ ██ ██   ██    ";
echo "   ██   ██ ██  ████ ██   ██ ██   ██ ██ ██   ██    ";
echo "    █████  ██   ███ ██   ██ ██   ██ ██ ██████     ";
echo "                                                  ";
echo "███████ ████████  █████  ████████ ██   ██ ███████ ";
echo "██         ██    ██   ██    ██    ██   ██ ██      ";
echo "███████    ██    ███████    ██    ██   ██ ███████ ";
echo "     ██    ██    ██   ██    ██    ██   ██      ██ ";
echo "███████    ██    ██   ██    ██     █████  ███████ ";
echo "                                                  ";
echo " ███████  █████ ██████  ███████ ███████ ███   ██  ";
echo " ██      ██     ██   ██ ██      ██      ████  ██  ";
echo " ███████ ██     ██████  █████   █████   ██ ██ ██  ";
echo "      ██ ██     ██   ██ ██      ██      ██  ████  ";
echo " ███████  █████ ██   ██ ███████ ███████ ██   ███  ";
echo "                                                  ";
echo "   ░       ░      ░             ░  ░     ░    ░   ";
echo " ░ ░  ░   ░░   ░  ▒  ░░      ░  ▒  ░ ░   ░    ░   ";
echo " ░ ▒  ▒   ░▒ ░ ▒░ ▒  ░▒ ░    ▒  ▒▒░░ ░   ░  ░ ▒  ░";
echo " ▒▒▓▒ ▒ ░ ▒▓ ░▒▓░░▓  ▒▓▒░ ░░▒▒  ▓▒▓░ ░▒  ▒ ░░ ▒░ ░";
echo "░▒▓▓▓▓▓ ░▓▓▓ ▒▓▓▒░▓▓░▒▓███  by: WeegeeNumbuh1  ███";

# fire up the script and watch over it
trap terminate SIGTERM
if [ ! -f "$PROFILING_FLAG" ];
then
	/usr/local/bin/python /app/main.py & child_pid=$!
	# pypy3 /app/main.py & child_pid=$!
	wait "$child_pid"
else
#	echo -e "${ORANGE}>>> Profiling enabled. Profile output will be generated every 60 seconds."
#	/usr/local/bin/python -m scalene --cli --reduced-profile --profile-interval 60 /app/main.py & child_pid=$!
	echo -e "${ORANGE}>>> ⚠️ Profiling enabled. You MUST run the below command in a new console window!"
	echo "/usr/local/bin/python -m scalene --cli --reduced-profile --profile-interval 60 /app/main.py"
	echo "Note: this can only be run once. The Docker must be restarted to profile again."
	echo "--- To disable profiling on the next run, rename or delete the \"profile\" file."
	/usr/local/bin/python -c "exec(\"import time\nwhile True: time.sleep(1)\")" & child_pid=$! # to keep the docker alive
	wait "$child_pid"
fi