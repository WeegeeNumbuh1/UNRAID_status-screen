import os
import board
import digitalio
import adafruit_rgb_display.ili9341 as ili9341
from PIL import Image
from pyftdi.ftdi import Ftdi
# check variables
print('Is the environment varible set?\n', os.environ["BLINKA_FT232H"])
print('Check if the display is connected:')
try:
    Ftdi().open_from_url('ftdi:///?')
except:
    pass
# Setup display
cs_pin = digitalio.DigitalInOut(board.C0)
dc_pin = digitalio.DigitalInOut(board.C1)
rst_pin = digitalio.DigitalInOut(board.D7)
disp = ili9341.ILI9341(board.SPI(), cs=cs_pin, dc=dc_pin, rst=rst_pin, baudrate=24000000)

# Load image and convert to RGB
image = Image.open('/app/blinka.bmp').convert('RGB')
print('Image generated.')

# Display it (rotated by 90 deg)
disp.image(image, 90)
