'''
UNRAID system monitoring screen script
Powered by Python, matplotlib, and psutil
Designed to run completely in Docker

by: WeegeeNumbuh1

Based on scripts from
https://github.com/adafruit/Adafruit_Learning_System_Guides/tree/main/TFT_Sidekick_With_FT232H
'''
import os
import time
import signal
import sys
import datetime
import threading
from collections import deque
# Blinka CircuitPython
import board
import digitalio
import adafruit_rgb_display.ili9341 as ili9341
from pyftdi.ftdi import Ftdi
# Python Imaging Library
from PIL import Image
# Matplotlib
import matplotlib.pyplot as plt
import matplotx
# System Stats
import psutil
from psutil._common import bytes2human

STARTED_DATE = datetime.datetime.now()
VERSION = "v.2.1 --- 2024-03-07"
print("Script version: %s" % VERSION)
print("Script started: %s" % STARTED_DATE)
start_time = round(time.time(), 3)

# Check variables
print('- Is the environment varible set?\n',os.environ["BLINKA_FT232H"])
print('- Check if the display is connected:')
try: # this will throw an error regardless
    Ftdi().open_from_url('ftdi:///?')
except:
    pass
    
# Setup display
cs_pin = digitalio.DigitalInOut(board.C0)
dc_pin = digitalio.DigitalInOut(board.C1)
rst_pin = digitalio.DigitalInOut(board.C2)
disp = ili9341.ILI9341(board.SPI(), cs=cs_pin, dc=dc_pin, rst=rst_pin, baudrate=24000000)
print("Plot size:", disp.width, "x", disp.height)

# Have a splash screen while loading
bg_image = Image.open('/app/background.bmp').convert('RGB')
disp.image(bg_image, 180)

# Check when the Docker is shutdown
def sigterm_handler(signal, frame):
    # raises SystemExit(0):
    disp.image(bg_image, 180) # leave a splash screen up when we exit
    end_time = round(time.time() - start_time, 3)
    print("- Script ran for %s" % str(datetime.timedelta(seconds=end_time)))
    print("Main loop stopped. See you next time!")
    sys.exit(0)

#==| User Config |========================================================
DEBUG = True # True = shows how long it took to render and display previous frame
'''
Don't set REFRESH_RATE too short - we don't want to waste too much CPU.
We need to allow update_plot() to finish while update_data() is still running
to get a more accurate represenation of CPU usage. The rendering portion
is the most CPU intensive action in this script.
Testing has shown it takes roughly 150 - 350 milliseconds to render
the entire plot and send it to the display; if REFRESH_RATE is too low then
we are limited to how fast update_plot() can complete.
REFRESH_RATE should be >= 0.5
'''
REFRESH_RATE = 2 # in seconds
HIST_SIZE = 61 # how long to keep data; total time = REFRESH_RATE * (HIST_SIZE - 1)
# /rootfs/mnt/user0 is our Unraid array inside this Docker
ARRAY_PATH = "/rootfs/mnt/user0"
'''
Check output of psutil.sensors_temperatures() on
your system then update the next line with the correct sensor.
''' 
CPU_TEMP_SENSOR = "k10temp"
''' 
valid plot properties are:
    title = name your subplot (not recommended with this setup)
    ylim (min, max) = y-axis limits
        nb: if ylim is not set, matplotlib will automatically scale
for lines:
    color, width, style, alpha
'''
PLOT_CONFIG = (
    #--------------------
    # PLOT 1 (upper plot)
    #--------------------
    {
    #'title' : 'CPU',
    'ylim' : (0, 100),
    'line_config' : (
        {'width': 1, 'alpha': 0.6}, # CPU
        {'width': 1, 'alpha': 0.6}  # Temps
        )
    },
    #--------------------
    # PLOT 2 (CPU core heatmap)
    #--------------------
    {
    #'title' : 'CPU heatmap',
    #'ylim' : (0, 100),
    'line_config' : (
        {}, # need this just so we can plot
        )
    },
    #--------------------
    # PLOT 3 (middle plot)
    #--------------------
    {
    #'title' : 'Disks (MB/s)',
    # 'ylim' : (0, 1000),
    'line_config' : (
        {'width': 1, 'alpha': 0.6}, # read
        {'width': 1, 'alpha': 0.6}, # write
        )
    },
    #--------------------
    # PLOT 4 (bottom plot)
    #--------------------
    {
    #'title' : 'Network (MB/s)',
    #'ylim' : (0, 1000),
    'line_config' : (
        {'width': 1, 'alpha': 0.6}, # sent
        {'width': 1, 'alpha': 0.6}, # received
        )
    },
    #--------------------
    # PLOT 5 (Resource usage)
    #--------------------
    {
    #'title' : 'Resources',
    'line_config' : (
        {} # a bar graph
    )
    }
)
# names in the center of the subplots, one per plot -REQUIRED-
ax_name = ("CPU", 
           "Core Heatmap", 
           "Disk", 
           "Network",
           "")
#==| End User Config |========================================================

def update_data():
    ''' Do whatever to update your data here. General form is:
           y_data[plot][line].append(new_data_point)
           
        Fun fact: this whole routine takes approximately 25 - 50 milliseconds to
        finish, ignorning the blocking done during the REFRESH_RATE interval.
    '''
    # data_start = round(time.time(), 3)
    def cpu_data_load():
        cpu_percs = psutil.cpu_percent(interval=REFRESH_RATE, percpu=False)
        y_data[0][0].append(cpu_percs)
        cpu_freq = psutil.cpu_freq() ; cpu_f_ghz = round(cpu_freq.current / 1000, 2)
        current_data[0] = str(cpu_percs) + "% @ " + str(cpu_f_ghz) + " GHz"
        # only because sensors_temperatures() does not exist in Windows; this was for testing
        try:
            psutil.sensors_temperatures()
        except:
            y_data[0][1].append(None)
            current_data[1] = None
        else:
            cpu_temp = psutil.sensors_temperatures()[CPU_TEMP_SENSOR][0].current
            y_data[0][1].append(cpu_temp)
            current_data[1] = str(round(cpu_temp, 1)) + "°C"
        
    def cpu_data_core():
        global cpu_percs_cores
        cpu_percs_cores = psutil.cpu_percent(interval=REFRESH_RATE, percpu=True)
        # then do this just in case the loop in update_plot() does something freaky
        y_data[1][0].append(1)

    def disk_data():
        # disk I/O, in MB/s
        disk_start = psutil.disk_io_counters()
        time.sleep(REFRESH_RATE)
        disk_finish = psutil.disk_io_counters()
        iospeed_read = (disk_finish.read_bytes - disk_start.read_bytes) / REFRESH_RATE
        iospeed_write = (disk_finish.write_bytes - disk_start.write_bytes) / REFRESH_RATE
        y_data[2][0].append(iospeed_read / 1e6)
        y_data[2][1].append(iospeed_write / 1e6)
        current_data[2] = "R:" + str(round(iospeed_read / 1e6, 2)) + " MB/s"
        current_data[3] = "W:" + str(round(iospeed_write / 1e6, 2)) + " MB/s"

    def network_data():
        # Network speed, in MB/s
        net_start = psutil.net_io_counters()
        time.sleep(REFRESH_RATE)
        net_finish = psutil.net_io_counters()
        network_sent = (net_finish.bytes_sent - net_start.bytes_sent) / REFRESH_RATE
        network_recv = (net_finish.bytes_recv - net_start.bytes_recv) / REFRESH_RATE
        y_data[3][0].append(network_sent / 1e6)
        y_data[3][1].append(network_recv / 1e6)
        current_data[4] = "↑" + str(round(network_sent / 1e6, 1)) + " MB/s"
        current_data[5] = "↓" + str(round(network_recv / 1e6, 1)) + " MB/s"
    
    # gather stats over REFRESH_RATE instead of waiting for each one sequentially 
    t1 = threading.Thread(target=cpu_data_load)
    t2 = threading.Thread(target=cpu_data_core)
    t3 = threading.Thread(target=disk_data)
    t4 = threading.Thread(target=network_data)
    t1.start() ; t2.start() ; t3.start() ; t4.start()
    t1.join() ; t2.join() ; t3.join() ; t4.join()
#    print("--- data: %s seconds ---" % (time.time() - (data_start + REFRESH_RATE)))

# Setup array of strings we can put latest sensor info into
current_data = []
for plot in PLOT_CONFIG: # this will make n+1 indices, perfect for our debug
    for _ in plot['line_config']:
        current_data.append(None)
if DEBUG == True:
    current_data[-1] = "" # utilize that last index
cpu_percs_cores = [] # setup array for CPU core utilization

# Setup X data storage
x_time = [x * REFRESH_RATE for x in range(HIST_SIZE)]
x_time.reverse()

# Setup Y data storage
y_data = [ [deque([None] * HIST_SIZE, maxlen=HIST_SIZE) for _ in plot['line_config']]
           for plot in PLOT_CONFIG
         ]

# Setup plot figure
plt.style.use(matplotx.styles.ayu['dark'])
fig, ax = plt.subplots(5, 1, figsize=(disp.width / 100, disp.height / 100), gridspec_kw={'height_ratios': [4, 1, 4, 4, 2]})
# fig, ax = plt.subplots(5, 1, figsize=(240 / 100, 320 / 100), gridspec_kw={'height_ratios': [4, 1, 4, 4, 2]}) # for debug
fig.subplots_adjust(0.0,0.12,1,0.98) # adjust extent of margins (left, bottom, right, top)
plt.rcParams.update({'font.size': 6})
# Set up text objects we can update
if DEBUG == True:
    debug_text = ax[4].annotate('', [1, -0.5], xycoords='axes fraction', 
                          verticalalignment='top', horizontalalignment='right')
cpu_text = ax[0].annotate('', [0.5, 0.3], xycoords='axes fraction', 
                          verticalalignment='center', horizontalalignment='center',
                          fontweight='black')
uptimetext = ax[2].annotate('', [0.5, 1.1], xycoords='axes fraction', 
                             verticalalignment='top', horizontalalignment='center',
                             alpha=1)
disk_text = ax[2].annotate('', [0.5, 0.3], xycoords='axes fraction', 
                          verticalalignment='center', horizontalalignment='center',
                          fontweight='black')
network_text = ax[3].annotate('', [0.5, 0.3], xycoords='axes fraction', 
                          verticalalignment='center', horizontalalignment='center',
                          fontweight='black')
memory_text = ax[4].annotate('', [0.5, 0.75], xycoords='axes fraction', 
                          verticalalignment='center', horizontalalignment='center',
                          fontweight='black')
storage_text = ax[4].annotate('', [0.5, 0.25], xycoords='axes fraction', 
                          verticalalignment='center', horizontalalignment='center',
                          fontweight='black')

def annotate_axes(ax, text, fontsize=10):
    ax.text(0.5, 0.5, text, transform=ax.transAxes,
            ha="center", va="center", fontsize=fontsize, 
            fontstyle='italic', fontweight='normal', 
            fontstretch= 750, alpha=0.25)
    
# make plot 4 a horizontal bar graph
ax[4].barh([1, 2], [0, 0]) ; ax[4].set_xlim(right=100)
ax[4].set_yticks([1, 2],["Array", "Memory"])

# Setup plot axis
for plot, a in enumerate(ax):
    a.xaxis.set_ticklabels([])
    a.tick_params(axis='y', labelsize=5)
    a.tick_params(axis="y", direction="in", pad=-20)
    if plot == 1 or plot == 4: # this is our CPU core heatmap & barplot
        a.tick_params(bottom = False, left=False)
    if plot == 1:
        a.yaxis.set_ticklabels([]) # turn off y-tick labels
    a.spines["top"].set_visible(False)  
    a.spines["bottom"].set_visible(False)  
    a.spines["right"].set_visible(False)  
    a.spines["left"].set_visible(False)
    # limit and invert x time axis
    if plot == 1 or plot == 4: # we don't need to set the x-limits here
        continue
    a.set_xlim(min(x_time), max(x_time))
    a.invert_xaxis()
    # custom settings
    if 'title' in PLOT_CONFIG[plot]:
        a.set_title(PLOT_CONFIG[plot]['title'], position=(0.5, 0.8))
    if 'ylim' in PLOT_CONFIG[plot]:
        a.set_ylim(PLOT_CONFIG[plot]['ylim'])
        
# Setup plot lines
plot_lines = []
for plot, config in enumerate(PLOT_CONFIG):
    lines = []
    for index, line_config in enumerate(config['line_config']):
        # create line
        line, = ax[plot].plot(x_time, y_data[plot][index])
        # custom settings
        if 'color' in line_config:
            line.set_color(line_config['color'])
        if 'width' in line_config:
            line.set_linewidth(line_config['width'])
        if 'style' in line_config:
            line.set_linestyle(line_config['style'])
        if 'alpha' in line_config:
            line.set_alpha(line_config['alpha'])
        # add line to list
        lines.append(line)
    plot_lines.append(lines)
    annotate_axes(ax[plot],ax_name[plot])

def update_plot():
    time.sleep(0.01) # allow update_data() to spawn its threads
    global current_data
    if DEBUG == True:
        plot_start = round(time.time(), 3)
    # gather system stats
    UPTIME = "Uptime: " + str(datetime.timedelta(seconds=round(time.monotonic())))
    array_use = psutil.disk_usage(ARRAY_PATH)
    array_total = bytes2human(array_use.total) ; array_used = bytes2human(array_use.used)
    array_str = array_used + ' / ' + array_total + ' (' + str(array_use.percent) + '%)'
    memory_use = psutil.virtual_memory()
    memory_total = bytes2human(memory_use.total) ; memory_used = bytes2human(memory_use.used)
    memory_str = memory_used + ' / ' + memory_total + ' (' + str(memory_use.percent) + '%)'
    # update lines with latest data
    for plot, lines in enumerate(plot_lines):
        if plot == 1 or plot == 4: # don't plot over the CPU heatmap
            continue
        for index, line in enumerate(lines):
            line.set_ydata(y_data[plot][index])
        # autoscale if not specified
        if 'ylim' not in PLOT_CONFIG[plot].keys():
            ax[plot].relim()
            ax[plot].autoscale_view()
    # our core heatmap writes to the 2nd plot
    ax[1].pcolormesh([cpu_percs_cores], cmap='hot', vmin=0, vmax=100)
    # utilization bar graph in 5th plot
    ax[4].barh(1, array_use.percent, facecolor='#375e1f')
    ax[4].barh(2, memory_use.percent, facecolor='#4a2a7a')
    # update text in plots with last polled data
    if current_data[1] == None:
        cpu_text.set_text(current_data[0])
    else:
        cpu_text.set_text(current_data[0] + " | " + current_data[1])
    disk_text.set_text(current_data[2] + " | " + current_data[3])
    storage_text.set_text(array_str)
    memory_text.set_text(memory_str)
    network_text.set_text(current_data[4] + " | " + current_data[5])
    uptimetext.set_text(UPTIME)
    if DEBUG == True:
        debug_text.set_text("Refresh rate: " + str(REFRESH_RATE) + "s | Last render: " + current_data[-1])
    # draw the plots
    canvas = plt.get_current_fig_manager().canvas
    canvas.draw()
    '''
    transfer into PIL image and display
    tostring_rgb() is depreciated in matplotlib >=3.8 with no direct replacement
    this will throw a warning on first run, oh well
    '''
    image = Image.frombytes('RGB', canvas.get_width_height(), canvas.tostring_rgb())
    disp.image(image, 180)
    if DEBUG == True:
        current_data[-1] = str(round(time.time() - plot_start, 3)) + "s"
#    print("--- generate: %s seconds ---" % (time.time() - plot_start))

def main():
    print("Setup took %s seconds" % round(time.time() - start_time, 3))
    print("--- Monitoring started, refresh rate: %s second(s) ---" % REFRESH_RATE)
    # register handler for SIGTERM
    signal.signal(signal.SIGTERM, sigterm_handler)
    if DEBUG == True:
        print("Performance tracing enabled, render times will be displayed.")
    update_data() # get initial stats on startup
    while True:
        t1 = threading.Thread(target=update_data)
        t2 = threading.Thread(target=update_plot)
        t1.start() ; t2.start()
        t2.join() ; t1.join()

# Finally enter main loop
if __name__ == '__main__':
    main()
